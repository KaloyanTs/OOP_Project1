#ifndef __TYPES_HPP
#define __TYPES_HPP

class String;
class Date;
class Room;
class HotelBuilding;
class Reservation;
class RoomAnalyzer;
class Hotel;

#endif