var _hotel_8hpp =
[
    [ "Hotel", "class_hotel.html", "class_hotel" ],
    [ "readFromIfstream", "_hotel_8hpp.html#a9c91dd5510c27bad0a47f88853c54029", null ]
];