var searchData=
[
  ['init_5fcapacity_0',['INIT_CAPACITY',['../_constants_8hpp.html#a8c29033b0c8f720cc599c3ab52679c80',1,'Constants.hpp']]],
  ['isactive_1',['isActive',['../class_reservation.html#ad058e62dd09a1bc29c0be56c1c7f25cc',1,'Reservation']]],
  ['isfreeinperiod_2',['isFreeInPeriod',['../class_room.html#ac5e5334be6c499b098394df2a4f2e5bc',1,'Room']]],
  ['isfreenow_3',['isFreeNow',['../class_room.html#a95cc43635356f64c587eb83a6c124cc8',1,'Room']]],
  ['isfreeondate_4',['isFreeOnDate',['../class_room.html#af7124ab1cb85e2d9d67c926aca7928ab',1,'Room']]],
  ['ispast_5',['isPast',['../class_reservation.html#a66002cd2cd0bc5c033fb3f50c21b5f30',1,'Reservation']]],
  ['isserviced_6',['isServiced',['../class_reservation.html#a33a56f239609b603a6b95348d19d41ee',1,'Reservation']]]
];
