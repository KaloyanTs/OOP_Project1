var class_reservation =
[
    [ "Reservation", "class_reservation.html#a1e0310dd853d63180cc12a51eb903978", null ],
    [ "Reservation", "class_reservation.html#ad5cb1df61535df3e87397e22e70450de", null ],
    [ "getFrom", "class_reservation.html#a229d88ec063e1aa55926ee148768f8c6", null ],
    [ "getNights", "class_reservation.html#ad9972d1080a65082bbfc809026a3f566", null ],
    [ "getNote", "class_reservation.html#a6b4cad025a943ddcd93a23b3e24c1ce2", null ],
    [ "getTo", "class_reservation.html#a0cf50c5405ca16f2cd49bd5cbd75b39f", null ],
    [ "isActive", "class_reservation.html#ad058e62dd09a1bc29c0be56c1c7f25cc", null ],
    [ "isPast", "class_reservation.html#a66002cd2cd0bc5c033fb3f50c21b5f30", null ],
    [ "isServiced", "class_reservation.html#a33a56f239609b603a6b95348d19d41ee", null ],
    [ "LeavingInAdvance", "class_reservation.html#a50cec33af6558c737a1b4d39051074e7", null ],
    [ "onDate", "class_reservation.html#a1d4f51265258703841bd7dfa84a8d019", null ],
    [ "operator=", "class_reservation.html#a51bbcf837255b6ce02e32ee384904a76", null ],
    [ "readDataFromBinary", "class_reservation.html#ac3f78877e46beaf123ef8a3b65d8a122", null ],
    [ "stateOnDate", "class_reservation.html#a5bc365d7f06207428c27053df2bb6cbc", null ],
    [ "writeToBinaryFile", "class_reservation.html#ae36a3bcd4fbf36472bdfd32a0ae755c6", null ]
];