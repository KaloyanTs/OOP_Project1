var searchData=
[
  ['readdatafrombinary_0',['readDataFromBinary',['../class_date.html#a4b3490040a1fb40aab75ddd34941d59f',1,'Date::readDataFromBinary()'],['../class_hotel_building.html#afebae062d697a16f7dc900bf3eb0d744',1,'HotelBuilding::readDataFromBinary()'],['../class_reservation.html#ac3f78877e46beaf123ef8a3b65d8a122',1,'Reservation::readDataFromBinary()'],['../class_room.html#a9c038a36c827904b435359c2deda3e1d',1,'Room::readDataFromBinary()']]],
  ['readfromifstream_1',['readFromIfstream',['../_hotel_8cpp.html#a9c91dd5510c27bad0a47f88853c54029',1,'readFromIfstream(std::ifstream &amp;ifs, size_t len):&#160;Hotel.cpp'],['../_hotel_8hpp.html#a9c91dd5510c27bad0a47f88853c54029',1,'readFromIfstream(std::ifstream &amp;ifs, size_t len):&#160;Hotel.cpp']]],
  ['readproper_2',['readProper',['../struct_date_period.html#ad1ed8aa41fecd42f1ea0d5c0250cddf4',1,'DatePeriod']]],
  ['reservation_3',['Reservation',['../class_reservation.html',1,'Reservation'],['../class_reservation.html#a1e0310dd853d63180cc12a51eb903978',1,'Reservation::Reservation(String name, const DatePeriod &amp;p, String n=&quot;None.\n&quot;, bool s=false)'],['../class_reservation.html#ad5cb1df61535df3e87397e22e70450de',1,'Reservation::Reservation(const Reservation &amp;)=delete']]],
  ['reservation_2ecpp_4',['Reservation.cpp',['../_reservation_8cpp.html',1,'']]],
  ['reservation_2ehpp_5',['Reservation.hpp',['../_reservation_8hpp.html',1,'']]],
  ['reservationstate_6',['ReservationState',['../_reservation_8hpp.html#a25e0fadea137a5363042c95e3e390785',1,'Reservation.hpp']]],
  ['reserveroom_7',['reserveRoom',['../class_hotel.html#a0fddb6befacc597d467dfe779e363bce',1,'Hotel']]],
  ['room_8',['Room',['../class_room.html',1,'Room'],['../class_room.html#ab64b84ed33b32bf6a37a4280efde4d96',1,'Room::Room(unsigned n, unsigned bC)'],['../class_room.html#a2a5725ae459e0ab9d327437f2764108a',1,'Room::Room(const Room &amp;)=delete']]],
  ['room_2ecpp_9',['Room.cpp',['../_room_8cpp.html',1,'']]],
  ['room_2ehpp_10',['Room.hpp',['../_room_8hpp.html',1,'']]],
  ['roomanalyzer_11',['RoomAnalyzer',['../class_room_analyzer.html',1,'RoomAnalyzer'],['../class_hotel_building.html#a0df6842918dbb3b3bdceaa909dccd25d',1,'HotelBuilding::RoomAnalyzer()']]],
  ['roomanalyzer_2ecpp_12',['RoomAnalyzer.cpp',['../_room_analyzer_8cpp.html',1,'']]],
  ['roomanalyzer_2ehpp_13',['RoomAnalyzer.hpp',['../_room_analyzer_8hpp.html',1,'']]]
];
