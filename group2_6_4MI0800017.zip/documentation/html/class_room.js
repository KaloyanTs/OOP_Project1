var class_room =
[
    [ "Room", "class_room.html#ab64b84ed33b32bf6a37a4280efde4d96", null ],
    [ "Room", "class_room.html#a2a5725ae459e0ab9d327437f2764108a", null ],
    [ "~Room", "class_room.html#a67d5da09983cc53097807fd43ba5481a", null ],
    [ "addReservation", "class_room.html#a5fe8859d069b3e6e40454bc581dadf13", null ],
    [ "closeForService", "class_room.html#ac35c972f948f0809ccefe3cbc4392449", null ],
    [ "freeRoom", "class_room.html#ac577ef1f89ef87ea45b5429b0a2728c2", null ],
    [ "getBedCount", "class_room.html#aa037073eacd079af9e7593f408a9e356", null ],
    [ "getNumber", "class_room.html#ae5ed5ee7959c90200d1e6d780167fe89", null ],
    [ "isFreeInPeriod", "class_room.html#ac5e5334be6c499b098394df2a4f2e5bc", null ],
    [ "isFreeNow", "class_room.html#a95cc43635356f64c587eb83a6c124cc8", null ],
    [ "isFreeOnDate", "class_room.html#af7124ab1cb85e2d9d67c926aca7928ab", null ],
    [ "newDate", "class_room.html#a61087b9ff006697919562e12b1af49c1", null ],
    [ "operator=", "class_room.html#aa1af14fb0a765044e8a8402b9907d1df", null ],
    [ "readDataFromBinary", "class_room.html#a9c038a36c827904b435359c2deda3e1d", null ],
    [ "showActivity", "class_room.html#a682629801e5debff24d82100bce83b95", null ],
    [ "showReservationsInPeriod", "class_room.html#a768c0c0119d139f2b5510ee101bbad7f", null ],
    [ "writeToBinaryFile", "class_room.html#abe060388698108735ef5a93d97c2e0ae", null ]
];