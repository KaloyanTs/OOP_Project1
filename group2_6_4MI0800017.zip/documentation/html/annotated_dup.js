var annotated_dup =
[
    [ "Date", "class_date.html", "class_date" ],
    [ "DatePeriod", "struct_date_period.html", "struct_date_period" ],
    [ "Hotel", "class_hotel.html", "class_hotel" ],
    [ "HotelBuilding", "class_hotel_building.html", "class_hotel_building" ],
    [ "HotelInterface", "class_hotel_interface.html", null ],
    [ "Reservation", "class_reservation.html", "class_reservation" ],
    [ "Room", "class_room.html", "class_room" ],
    [ "RoomAnalyzer", "class_room_analyzer.html", null ],
    [ "String", "class_string.html", "class_string" ]
];