var _hotel_8cpp =
[
    [ "readFromIfstream", "_hotel_8cpp.html#a9c91dd5510c27bad0a47f88853c54029", null ]
];