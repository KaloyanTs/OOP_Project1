var searchData=
[
  ['bibliography_2emd_0',['bibliography.md',['../bibliography_8md.html',1,'']]]
];
