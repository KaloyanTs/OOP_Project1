var files_dup =
[
    [ "markdowns", "dir_822baa1b6b19661f487f1ae52567a2eb.html", null ],
    [ "Constants.hpp", "_constants_8hpp.html", "_constants_8hpp" ],
    [ "Date.cpp", "_date_8cpp.html", "_date_8cpp" ],
    [ "Date.hpp", "_date_8hpp.html", "_date_8hpp" ],
    [ "Hotel.cpp", "_hotel_8cpp.html", "_hotel_8cpp" ],
    [ "Hotel.hpp", "_hotel_8hpp.html", "_hotel_8hpp" ],
    [ "HotelBuilding.cpp", "_hotel_building_8cpp.html", null ],
    [ "HotelBuilding.hpp", "_hotel_building_8hpp.html", [
      [ "HotelBuilding", "class_hotel_building.html", "class_hotel_building" ]
    ] ],
    [ "HotelInterface.cpp", "_hotel_interface_8cpp.html", null ],
    [ "HotelInterface.hpp", "_hotel_interface_8hpp.html", [
      [ "HotelInterface", "class_hotel_interface.html", null ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Reservation.cpp", "_reservation_8cpp.html", null ],
    [ "Reservation.hpp", "_reservation_8hpp.html", "_reservation_8hpp" ],
    [ "Room.cpp", "_room_8cpp.html", "_room_8cpp" ],
    [ "Room.hpp", "_room_8hpp.html", "_room_8hpp" ],
    [ "RoomAnalyzer.cpp", "_room_analyzer_8cpp.html", null ],
    [ "RoomAnalyzer.hpp", "_room_analyzer_8hpp.html", [
      [ "RoomAnalyzer", "class_room_analyzer.html", null ]
    ] ],
    [ "String.cpp", "_string_8cpp.html", "_string_8cpp" ],
    [ "String.hpp", "_string_8hpp.html", "_string_8hpp" ],
    [ "Types.hpp", "_types_8hpp.html", null ]
];