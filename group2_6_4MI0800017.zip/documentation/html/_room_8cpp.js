var _room_8cpp =
[
    [ "operator<<", "_room_8cpp.html#ac26610f31a63700cf2018499b080b394", null ]
];