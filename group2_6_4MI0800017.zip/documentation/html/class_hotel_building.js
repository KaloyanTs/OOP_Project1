var class_hotel_building =
[
    [ "HotelBuilding", "class_hotel_building.html#a0b44f6281acbeffb9bc4ff13b49c503c", null ],
    [ "HotelBuilding", "class_hotel_building.html#a91f8a66bf8af1eaacef5a3d96a62d255", null ],
    [ "~HotelBuilding", "class_hotel_building.html#a8c09c46d278197749825c0135b03da18", null ],
    [ "createReport", "class_hotel_building.html#a590e77a77e5e1d2c93d12df5f60d128c", null ],
    [ "getRoomCount", "class_hotel_building.html#aac84c36001ea2dd2a085c861e39ec7b0", null ],
    [ "newDate", "class_hotel_building.html#a7e02a06c388ca30205b9ee7d832c8c5e", null ],
    [ "operator=", "class_hotel_building.html#a35d48dc36daf9aee976f7e71d731beed", null ],
    [ "operator[]", "class_hotel_building.html#a2d5769bf590157c81b17c29393515533", null ],
    [ "readDataFromBinary", "class_hotel_building.html#afebae062d697a16f7dc900bf3eb0d744", null ],
    [ "showAvailableRooms", "class_hotel_building.html#acb8b2fa415c1718a6a8bae7fddc7b06d", null ],
    [ "showRoomForNights", "class_hotel_building.html#a58478b5b1c8bf84ddd2cdba250425d5c", null ],
    [ "showRoomsStatesToday", "class_hotel_building.html#a5d49615b93b269a461a5ddf921c545e5", null ],
    [ "suggestRoom", "class_hotel_building.html#a8e5c528b9b54198c20333764275a7280", null ],
    [ "writeToBinaryFile", "class_hotel_building.html#a331590bfb72cbdfbcda776c7f49780e8", null ],
    [ "RoomAnalyzer", "class_hotel_building.html#a0df6842918dbb3b3bdceaa909dccd25d", null ]
];