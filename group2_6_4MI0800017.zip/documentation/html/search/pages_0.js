var searchData=
[
  ['bibliography_0',['Bibliography',['../md_markdowns_bibliography.html',1,'']]]
];
