var class_string =
[
    [ "String", "class_string.html#a6e005d5422ee34c9e8e006cd96742f12", null ],
    [ "String", "class_string.html#afc158dffcdf56e601bd640cbacdfcd3c", null ],
    [ "~String", "class_string.html#ac40b2a3fb58c2d8556f5e6ff73510036", null ],
    [ "c_str", "class_string.html#ab92e6017bdb72ff5ee8f4281df7c8f8e", null ],
    [ "capacity", "class_string.html#a1122194c4c53b8bcc9b7c4df21c60e8e", null ],
    [ "operator const char *", "class_string.html#a9a12caedc885ac44c86d104a8cb60f82", null ],
    [ "operator+", "class_string.html#ac094f267da5e0cdc7559bb1fa163f650", null ],
    [ "operator+=", "class_string.html#ab84728b14cac3bc213351c8ae8fb3364", null ],
    [ "operator=", "class_string.html#a734f34a0b7a42bcad30c368d6e8c5469", null ],
    [ "shrink_to_fit", "class_string.html#a12893a9387a85a6d20b2c4e49729ccec", null ],
    [ "size", "class_string.html#a588c5cc9faededbb9d938662d354feed", null ]
];