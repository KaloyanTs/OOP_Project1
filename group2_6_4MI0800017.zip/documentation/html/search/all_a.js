var searchData=
[
  ['newdate_0',['newDate',['../class_hotel_building.html#a7e02a06c388ca30205b9ee7d832c8c5e',1,'HotelBuilding::newDate()'],['../class_room.html#a61087b9ff006697919562e12b1af49c1',1,'Room::newDate()']]],
  ['nextday_1',['nextDay',['../class_hotel.html#a7b23fa694af4aa49b4f958ce2ba84609',1,'Hotel']]]
];
