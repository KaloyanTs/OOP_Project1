var searchData=
[
  ['searchroom_0',['searchRoom',['../class_hotel.html#a3077074d8a8b2dcc081613916de156ed',1,'Hotel']]],
  ['seeroomfornights_1',['seeRoomForNights',['../class_hotel.html#ab988068aa218eba516bc1476de33e8de',1,'Hotel']]],
  ['serviceroom_2',['serviceRoom',['../class_hotel.html#a3c2277e226ef44245a0cc255e8de4d17',1,'Hotel']]],
  ['showactivity_3',['showActivity',['../class_room.html#a682629801e5debff24d82100bce83b95',1,'Room']]],
  ['showavailablerooms_4',['showAvailableRooms',['../class_hotel.html#ab97f370156fb0c717f5c5c3c261316d0',1,'Hotel::showAvailableRooms()'],['../class_hotel_building.html#acb8b2fa415c1718a6a8bae7fddc7b06d',1,'HotelBuilding::showAvailableRooms()']]],
  ['showreservationsinperiod_5',['showReservationsInPeriod',['../class_room.html#a768c0c0119d139f2b5510ee101bbad7f',1,'Room']]],
  ['showroomfornights_6',['showRoomForNights',['../class_hotel_building.html#a58478b5b1c8bf84ddd2cdba250425d5c',1,'HotelBuilding']]],
  ['showroomsstatestoday_7',['showRoomsStatesToday',['../class_hotel_building.html#a5d49615b93b269a461a5ddf921c545e5',1,'HotelBuilding']]],
  ['showtoday_8',['showToday',['../class_hotel.html#a02ca70d80af5cf9ee523a18525675dc8',1,'Hotel']]],
  ['shrink_5fto_5ffit_9',['shrink_to_fit',['../class_string.html#a12893a9387a85a6d20b2c4e49729ccec',1,'String']]],
  ['size_10',['size',['../class_string.html#a588c5cc9faededbb9d938662d354feed',1,'String']]],
  ['soonestfreeperiod_11',['soonestFreePeriod',['../class_room_analyzer.html#afde57c7d421cca78025cbe1434a53b7d',1,'RoomAnalyzer']]],
  ['stateondate_12',['stateOnDate',['../class_reservation.html#a5bc365d7f06207428c27053df2bb6cbc',1,'Reservation']]],
  ['string_13',['String',['../class_string.html#a6e005d5422ee34c9e8e006cd96742f12',1,'String::String(const char *_str=&quot;&quot;)'],['../class_string.html#afc158dffcdf56e601bd640cbacdfcd3c',1,'String::String(const String &amp;other)']]],
  ['suggest_14',['suggest',['../class_room_analyzer.html#a212c689f6a7cd12f9792bee43b6742ae',1,'RoomAnalyzer']]],
  ['suggestroom_15',['suggestRoom',['../class_hotel_building.html#a8e5c528b9b54198c20333764275a7280',1,'HotelBuilding']]]
];
