var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_date.html#af7ada80c7c34b250f290a8008f0fc047',1,'Date']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../class_date.html#abf20d922f989d05f4a4dda4b4b8238e9',1,'Date']]]
];
