var _reservation_8hpp =
[
    [ "Reservation", "class_reservation.html", "class_reservation" ],
    [ "ReservationState", "_reservation_8hpp.html#a25e0fadea137a5363042c95e3e390785", [
      [ "UNKNOWN", "_reservation_8hpp.html#a25e0fadea137a5363042c95e3e390785a6ce26a62afab55d7606ad4e92428b30c", null ],
      [ "PAST", "_reservation_8hpp.html#a25e0fadea137a5363042c95e3e390785aa6f490707e32c41c5777b99299f9167c", null ],
      [ "ACTIVE", "_reservation_8hpp.html#a25e0fadea137a5363042c95e3e390785a33cf1d8ef1d06ee698a7fabf40eb3a7f", null ],
      [ "FUTURE", "_reservation_8hpp.html#a25e0fadea137a5363042c95e3e390785aac3a374d7888bb712d78f8b81ece4f15", null ]
    ] ],
    [ "operator<<", "_reservation_8hpp.html#a93d6415495dadcc9c0a91e8643f22330", null ]
];