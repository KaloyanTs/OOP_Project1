var _room_8hpp =
[
    [ "Room", "class_room.html", "class_room" ],
    [ "operator<<", "_room_8hpp.html#ac26610f31a63700cf2018499b080b394", null ]
];